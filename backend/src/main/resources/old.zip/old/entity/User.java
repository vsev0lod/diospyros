package com.diospyros.uplift.entity;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User extends BaseEntity {
//    String username;
//    Long avatarId;
    String email;
    String password;
    Long rating;
    String type;
    String name;
    String description;
    Long balance;
//    @CreationTimestamp
//    @Temporal(TemporalType.TIMESTAMP)
//    @Column(name = "created_at", updatable = false)
//    Date createdAt;
}
