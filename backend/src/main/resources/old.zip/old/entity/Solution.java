package com.diospyros.uplift.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "solution")
public class Solution extends BaseEntity {
    private String description;
    //    private Entity entity;
    @OneToOne(mappedBy = "solution")
    private Task task;
    @OneToOne(mappedBy = "solution")
    private User creatorId;
}
