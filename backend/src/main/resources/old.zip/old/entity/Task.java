package com.diospyros.uplift.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "task")
public class Task extends BaseEntity {
    // Java model to store Tasks
    // it should contain task id, author id, photo, description, location, reward, status(enum), executor id, report
    // id, created at
    // id - id of the task
    //  authorId - id of the author
    //  photo - photo of the task
    //  description - description of the task
    //  location - location of the task
    //  reward - reward of the task
    //  status - status of the task - enum (created, in progress, completed)
    //  executorId - id of the executor
    //  reportId - id of the report
    //  createdAt - date of creation of the task

//    int authorId;
//    String photo;
    String title;
    String description;
    String type;
    Long reward;
    @OneToOne(mappedBy = "task")
    Location location;
//    entity
    String status;
    @OneToOne(mappedBy = "task")
    User creator;
    String tag;

//    int executorId;
//    int reportId;
//    @CreationTimestamp
//    @Temporal(TemporalType.TIMESTAMP)
//    @Column(name = "created_at", updatable = false)
//    Date createdAt;
}
