package com.diospyros.uplift.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Value;

//@Entity
//@Setter
//@Getter
//@Builder
//@NoArgsConstructor
//@AllArgsConstructor
//@Table(name = "avatar")
//public class Avatar extends BaseEntity{
//    // Java model to store Avatars for the users
//    // It should contain avatar id, and image
//    // id - id of the avatar
//    // image - image of the avatar base64 encoded
//    String image;
//}
