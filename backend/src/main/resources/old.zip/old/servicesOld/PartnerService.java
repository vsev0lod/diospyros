package com.diospyros.uplift.servicesOld;

import com.diospyros.uplift.repositories.PartnerRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PartnerService {
    @Autowired
    private PartnerRepository partnerRepository;
}
