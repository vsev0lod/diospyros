package com.diospyros.uplift.servicesOld;

import com.diospyros.uplift.entity.User;
import com.diospyros.uplift.repositories.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User getUser() {
        //return userRepository.getReferenceById()
//        return new User(1L, "Vasya", "vasye@email.com", 0L, 42L, new Date());
    return new User("vasya228@gmail.com","passwd222",5L,"private","VasiliyIvamov","ya prosto vasya",100L);
    }

}
