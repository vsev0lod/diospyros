package com.diospyros.uplift.controllersOld;

public class LocationController {
}
